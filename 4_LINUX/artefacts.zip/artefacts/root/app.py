import http.server
import socketserver
import ssl
import os

# Заполнить значения
STUDENT_SURNAME = "Сакулин"
STUDENT_NAME = "Иван"
CERT_FILE = "./cert/site_safronovis.crt"
KEY_FILE = "./cert/site.key"

PORT = 443

class MyHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-type", "text/plain; charset=utf-8")
        self.end_headers()

        response_text = (
            f"Это виртуальная машина студента: {STUDENT_SURNAME} {STUDENT_NAME}\n"
            f"IP-адрес клиента: {self.client_address[0]}\n"
        )

        self.wfile.write(response_text.encode("utf-8"))

httpd = socketserver.TCPServer(("", PORT), MyHandler)

context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
context.load_cert_chain(certfile=CERT_FILE, keyfile=KEY_FILE)

httpd.socket = context.wrap_socket(httpd.socket, server_side=True)

print(f"HTTPS сервер запущен на порту {PORT}")

httpd.serve_forever()
