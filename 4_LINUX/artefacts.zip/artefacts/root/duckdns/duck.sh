echo url="https://www.duckdns.org/update?domains=otz.duckdns.org&token=f402182e-7278-4152-9000-0b6f9da41d75&ip=" | curl -k -o ~/duckdns/duck.log -K -
